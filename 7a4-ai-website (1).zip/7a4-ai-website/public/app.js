const chat = document.getElementById("chat");
const welcome = document.getElementById("welcome");
const form = document.getElementById("composer");
const input = document.getElementById("prompt");
const send = document.getElementById("send");
const history = [];

function addMessage(role, content, extraClass = "") {
  if (welcome) welcome.remove();
  const row = document.createElement("div");
  row.className = `message ${role} ${extraClass}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "B" : "7";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = content;
  row.append(avatar, bubble);
  chat.appendChild(row);
  chat.scrollTop = chat.scrollHeight;
  return bubble;
}

async function sendMessage(text) {
  const content = text.trim();
  if (!content || send.disabled) return;
  addMessage("user", content);
  history.push({ role: "user", content });
  input.value = "";
  input.style.height = "auto";
  send.disabled = true;
  const waiting = addMessage("assistant", "7a4 đang suy nghĩ...", "typing");
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: history })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Có lỗi xảy ra.");
    waiting.textContent = data.answer;
    waiting.parentElement.classList.remove("typing");
    history.push({ role: "assistant", content: data.answer });
  } catch (error) {
    waiting.textContent = "⚠️ " + error.message;
    waiting.parentElement.classList.remove("typing");
  } finally {
    send.disabled = false;
    input.focus();
    chat.scrollTop = chat.scrollHeight;
  }
}

form.addEventListener("submit", e => {
  e.preventDefault();
  sendMessage(input.value);
});
input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 150) + "px";
});
input.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    form.requestSubmit();
  }
});
document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});
document.getElementById("newChat").addEventListener("click", () => {
  history.length = 0;
  chat.innerHTML = `<div id="welcome" class="welcome"><div class="welcome-logo">7</div><h1>Xin chào! Mình là <span>7a4</span></h1><p>Mình có thể giúp bạn học tập, tìm ý tưởng và giải đáp thắc mắc.</p><div class="quick-grid"><button data-prompt="Hãy giúp mình ôn tập Toán lớp 7."><b>📘 Ôn tập Toán</b><small>Giải thích dễ hiểu từng bước</small></button><button data-prompt="Hãy giúp mình viết một đoạn văn tiếng Anh đơn giản."><b>🌍 Học tiếng Anh</b><small>Từ vựng và ngữ pháp</small></button><button data-prompt="Gợi ý cho mình một ý tưởng sáng tạo."><b>💡 Tìm ý tưởng</b><small>Khơi nguồn sáng tạo</small></button><button data-prompt="Kể cho mình một sự thật thú vị về vũ trụ."><b>🚀 Khám phá</b><small>Kiến thức thú vị mỗi ngày</small></button></div></div>`;
  document.querySelectorAll("[data-prompt]").forEach(button => button.addEventListener("click", () => sendMessage(button.dataset.prompt)));
  input.focus();
});
document.getElementById("menuBtn").addEventListener("click", () => document.querySelector(".sidebar").classList.toggle("open"));
