require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-6";

app.post("/api/chat", async (req, res) => {
  try {
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Tin nhắn không hợp lệ." });
    }
    if (!API_KEY) {
      return res.status(503).json({
        error: "Website chưa được kết nối AI. Hãy thêm OPENAI_API_KEY vào file .env rồi khởi động lại."
      });
    }

    const safeMessages = messages.slice(-16).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 6000)
    }));

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        instructions: "Bạn là 7a4, một trợ lý AI thân thiện nói tiếng Việt. Trả lời rõ ràng, hữu ích, trung thực; giải thích từng bước khi học sinh cần. Nếu không biết thì nói rõ, không bịa thông tin. Dùng ngôn ngữ phù hợp lứa tuổi.",
        input: safeMessages.map(m => ({
          role: m.role,
          content: [{ type: "input_text", text: m.content }]
        }))
      })
    });

    const data = await response.json();
    if (!response.ok) {
      console.error("OpenAI API error:", data);
      return res.status(response.status).json({
        error: data.error?.message || "Không thể kết nối dịch vụ AI. Hãy kiểm tra API key và model."
      });
    }

    const answer = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text)
      .join("\n");

    res.json({ answer: answer || "Mình chưa tạo được câu trả lời. Bạn thử hỏi lại nhé!" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Có lỗi máy chủ. Vui lòng thử lại." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`7a4 đang chạy tại http://localhost:${port}`));