7a4 — WEBSITE TRỢ LÝ AI
=======================

YÊU CẦU
- Máy tính có cài Node.js phiên bản 18 trở lên.
- Một API key của OpenAI để bật trả lời bằng AI.
- Kết nối Internet.

CÀI ĐẶT
1. Giải nén file ZIP.
2. Mở thư mục 7a4-ai-website.
3. Tạo bản sao của .env.example và đổi tên bản sao thành .env.
4. Mở .env bằng Notepad, thay phần sau OPENAI_API_KEY= bằng API key của bạn.
   Không gửi API key cho người khác, không đưa key vào file trong thư mục public.
5. Mở Terminal/CMD tại thư mục dự án và chạy:
      npm install
      npm start
6. Mở trình duyệt và truy cập:
      http://localhost:3000

ĐỔI MODEL
- Nếu tài khoản API của bạn không hỗ trợ model mặc định gpt-6-luna, hãy đổi OPENAI_MODEL trong .env
  thành tên model được hiển thị trong tài khoản/API docs của bạn.

LƯU Ý
- Website chạy trên máy tính của bạn; người khác chưa thể truy cập từ Internet.
- Muốn đưa website lên mạng, cần triển khai server Node.js trên một dịch vụ hosting.
- API key là bí mật. Không đặt key trong public/app.js hoặc index.html.
- Chi phí API (nếu có) phụ thuộc tài khoản và mức sử dụng. Kiểm tra trước khi dùng.
- Đây là mã nguồn khởi đầu có giao diện chat, lịch sử trong phiên hiện tại, gợi ý câu hỏi,
  xử lý lỗi và backend giữ API key ở phía máy chủ. Lịch sử chưa được lưu sau khi tải lại trang.
